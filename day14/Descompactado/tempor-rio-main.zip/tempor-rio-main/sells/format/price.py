def real(value):
    return f'R${value:.2f}'.replace('.', ',')