products = [
    {'Name': 'p1', 'preco': 50},
    {'Name': 'p2', 'preco': 150},
    {'Name': 'p3', 'preco': 15.90},
    {'Name': 'p4', 'preco': 40},
    {'Name': 'p5', 'preco': 56},
    {'Name': 'p6', 'preco': 89},
    {'Name': 'p7', 'preco': 5.3},
    {'Name': 'p8', 'preco': 350.10},
    {'Name': 'p9', 'preco': 36},
    {'Name': 'p10', 'preco': 14}
]

people = [
    {'name': 'Maria', 'age': 18},
    {'name': 'Vinicius', 'age': 29},
    {'name': 'Carlos', 'age': 17},
    {'name': 'Beato', 'age': 30},
    {'name': 'Jay', 'age': 27},
    {'name': 'Jayden', 'age': 24},
    {'name': 'Magno', 'age': 13},
    {'name': 'Malta', 'age': 45},
    {'name': 'Ricardo', 'age': 56},
    {'name': 'Ohara', 'age': 20}
]
list1 = [1,2,3,4,5,6,7,8,9,10]